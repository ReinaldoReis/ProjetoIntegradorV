from flask import Flask
from flask_restful import reqparse, abort, Api, Resource

app = Flask(__name__)
api = Api(app)

IMIGRANTES = {
    
    'imigrante1': {'task': 'Nicolas Hernandes'},
    'imigrante2': {'task': 'Juan Garcia'},
    'imigrante3': {'task': 'Agostina Lopez'}

}

def abort_if_imigrante_doesnt_exist(imigrante_id):
    if imigrante_id not in IMIGRANTES:
        abort(404, message="Imigrante {} doesn't exist".format(imigrante_id))

parser = reqparse.RequestParser()
parser.add_argument('task')

# Imigrante resource
class Imigrante(Resource):
    def get(self, imigrante_id):
        abort_if_imigrante_doesnt_exist(imigrante_id)
        return IMIGRANTES[imigrante_id]

    def delete(self, imigrante_id):
        abort_if_imigrante_doesnt_exist(imigrante_id)
        del IMIGRANTES[imigrante_id]
        return '', 204

    def put(self, imigrante_id):
        args = parser.parse_args()
        task = {'task': args['task']}
        IMIGRANTES[imigrante_id] = task
        return task, 200

# Imigrante list resource
class ImigranteList(Resource):
    def get(self):
        return IMIGRANTES

    def post(self):
        args = parser.parse_args()
        imigrante_id = int(max(IMIGRANTES.keys()).lstrip('imigrante')) + 1
        imigrante_id = 'imigrante%i' % imigrante_id
        IMIGRANTES[imigrante_id] = {'task': args['task']}
        return IMIGRANTES[imigrante_id], 201

# add resources to api
api.add_resource(ImigranteList, '/imigrante')
api.add_resource(Imigrante, '/imigrante/<imigrante_id>')

if __name__ == '__main__':
    app.run(debug=True)